#!/usr/bin/env python3
"""Minimal ChromaColors Cloud server.

This server intentionally uses only the Python standard library so it can be
started on a clean VPS without installing dependencies.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import html
import json
import os
import secrets
import sqlite3
import time
import uuid
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlparse


APP_NAME = "ChromaColors Cloud"
DATA_DIR = Path(os.environ.get("CHROMA_DATA_DIR", Path(__file__).parent / "data"))
DB_PATH = Path(os.environ.get("CHROMA_DB", DATA_DIR / "chromacolors_cloud.sqlite3"))
SECRET = os.environ.get("CHROMA_SECRET", "change-this-secret-before-production")
PUBLIC_KEY = os.environ.get("CHROMA_PUBLIC_KEY", "cromacolors_publishable_key")
BASE_URL = os.environ.get("CHROMA_BASE_URL", "https://claud.chromacolor.shop")
ACCESS_TOKEN_TTL = int(os.environ.get("CHROMA_ACCESS_TOKEN_TTL", "3600"))
AUTH_CODE_TTL = int(os.environ.get("CHROMA_AUTH_CODE_TTL", "300"))


def now() -> int:
    return int(time.time())


def b64url(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def json_dumps(data: Any) -> bytes:
    return json.dumps(data, separators=(",", ":"), ensure_ascii=True).encode("utf-8")


def password_hash(password: str, salt: str | None = None) -> str:
    salt = salt or secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt.encode("ascii"), 200_000)
    return f"pbkdf2_sha256${salt}${b64url(digest)}"


def verify_password(password: str, encoded: str) -> bool:
    try:
        algorithm, salt, expected = encoded.split("$", 2)
    except ValueError:
        return False
    if algorithm != "pbkdf2_sha256":
        return False
    candidate = password_hash(password, salt).split("$", 2)[2]
    return hmac.compare_digest(candidate, expected)


def sha256_pkce(verifier: str) -> str:
    return b64url(hashlib.sha256(verifier.encode("ascii")).digest())


def sign_token(payload: dict[str, Any]) -> str:
    header = {"alg": "HS256", "typ": "JWT"}
    head = b64url(json_dumps(header))
    body = b64url(json_dumps(payload))
    message = f"{head}.{body}".encode("ascii")
    signature = b64url(hmac.new(SECRET.encode("utf-8"), message, hashlib.sha256).digest())
    return f"{head}.{body}.{signature}"


def decode_token(token: str) -> dict[str, Any] | None:
    try:
        head, body, signature = token.split(".", 2)
        message = f"{head}.{body}".encode("ascii")
        expected = b64url(hmac.new(SECRET.encode("utf-8"), message, hashlib.sha256).digest())
        if not hmac.compare_digest(signature, expected):
            return None
        padded = body + "=" * (-len(body) % 4)
        payload = json.loads(base64.urlsafe_b64decode(padded.encode("ascii")))
        if int(payload.get("exp", 0)) < now():
            return None
        return payload
    except Exception:
        return None


def db() -> sqlite3.Connection:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con


def init_db() -> None:
    with db() as con:
        con.executescript(
            """
            create table if not exists users (
                id text primary key,
                email text not null unique,
                display_name text not null,
                password_hash text not null,
                created_at integer not null
            );

            create table if not exists auth_codes (
                code text primary key,
                user_id text not null,
                state text not null,
                code_challenge text not null,
                code_challenge_method text not null,
                expires_at integer not null,
                used_at integer,
                foreign key(user_id) references users(id)
            );

            create table if not exists refresh_tokens (
                token_hash text primary key,
                user_id text not null,
                created_at integer not null,
                revoked_at integer,
                foreign key(user_id) references users(id)
            );

            create table if not exists sync_items (
                user_id text not null,
                item_key text not null,
                payload text not null,
                updated_at integer not null,
                primary key(user_id, item_key)
            );
            """
        )


def hash_token(token: str) -> str:
    return hashlib.sha256(token.encode("ascii")).hexdigest()


def get_or_create_user(email: str, password: str, display_name: str) -> sqlite3.Row:
    email = email.strip().lower()
    display_name = display_name.strip() or email.split("@", 1)[0]
    with db() as con:
        user = con.execute("select * from users where email = ?", (email,)).fetchone()
        if user:
            if not verify_password(password, user["password_hash"]):
                raise ValueError("invalid credentials")
            return user

        user_id = str(uuid.uuid4())
        con.execute(
            "insert into users (id, email, display_name, password_hash, created_at) values (?, ?, ?, ?, ?)",
            (user_id, email, display_name, password_hash(password), now()),
        )
        return con.execute("select * from users where id = ?", (user_id,)).fetchone()


def user_payload(user: sqlite3.Row) -> dict[str, Any]:
    username = user["email"].split("@", 1)[0]
    return {
        "id": user["id"],
        "email": user["email"],
        "user_metadata": {
            "username": username,
            "display_name": user["display_name"],
            "name": user["display_name"],
            "avatar_url": "",
        },
    }


def session_payload(user: sqlite3.Row, refresh_token: str | None = None) -> dict[str, Any]:
    issued_at = now()
    expires_at = issued_at + ACCESS_TOKEN_TTL
    access_token = sign_token(
        {
            "iss": APP_NAME,
            "sub": user["id"],
            "email": user["email"],
            "iat": issued_at,
            "exp": expires_at,
            "aud": "authenticated",
        }
    )
    if refresh_token is None:
        refresh_token = secrets.token_urlsafe(48)
        with db() as con:
            con.execute(
                "insert into refresh_tokens (token_hash, user_id, created_at, revoked_at) values (?, ?, ?, null)",
                (hash_token(refresh_token), user["id"], issued_at),
            )
    return {
        "access_token": access_token,
        "refresh_token": refresh_token,
        "token_type": "bearer",
        "expires_in": ACCESS_TOKEN_TTL,
        "expires_at": expires_at,
        "user": user_payload(user),
    }


def create_auth_code(user_id: str, state: str, code_challenge: str, method: str) -> str:
    code = secrets.token_urlsafe(32)
    with db() as con:
        con.execute(
            """
            insert into auth_codes
            (code, user_id, state, code_challenge, code_challenge_method, expires_at, used_at)
            values (?, ?, ?, ?, ?, ?, null)
            """,
            (code, user_id, state, code_challenge, method, now() + AUTH_CODE_TTL),
        )
    return code


def read_json(handler: BaseHTTPRequestHandler) -> dict[str, Any]:
    length = int(handler.headers.get("Content-Length", "0"))
    if length <= 0:
        return {}
    raw = handler.rfile.read(length).decode("utf-8")
    content_type = handler.headers.get("Content-Type", "")
    if "application/x-www-form-urlencoded" in content_type:
        return {key: values[-1] for key, values in parse_qs(raw).items()}
    return json.loads(raw or "{}")


def login_page() -> str:
    title = html.escape(APP_NAME)
    base_url = html.escape(BASE_URL)
    return f"""<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>{title}</title>
  <style>
    body {{ margin:0; font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif; background:#101820; color:#f5f7fa; }}
    main {{ max-width:420px; margin:10vh auto; padding:28px; }}
    h1 {{ margin:0 0 8px; font-size:28px; }}
    p {{ color:#b8c2cc; }}
    label {{ display:block; margin-top:16px; color:#dce3ea; font-size:14px; }}
    input {{ width:100%; box-sizing:border-box; margin-top:6px; padding:12px; border:1px solid #425466; border-radius:8px; background:#172331; color:#fff; }}
    button {{ width:100%; margin-top:22px; padding:12px; border:0; border-radius:8px; background:#22c55e; color:#06110a; font-weight:700; cursor:pointer; }}
    .error {{ margin-top:14px; color:#ffb4a8; min-height:20px; }}
  </style>
</head>
<body>
  <main>
    <h1>{title}</h1>
    <p>Entre ou crie sua conta para sincronizar perfis no ChromaColors.</p>
    <label>Nome<input id="name" autocomplete="name" placeholder="Seu nome"></label>
    <label>Email<input id="email" type="email" autocomplete="email" placeholder="voce@email.com"></label>
    <label>Senha<input id="password" type="password" autocomplete="current-password" placeholder="Minimo 6 caracteres"></label>
    <button id="submit">Entrar / Criar conta</button>
    <div class="error" id="error"></div>
  </main>
  <script>
    let loginConfig = null;
    const fallbackBaseUrl = "{base_url}";

    function wxPost(payload) {{
      const text = JSON.stringify(payload);
      if (window.wx && window.wx.postMessage) return window.wx.postMessage(text);
      if (window.chrome && window.chrome.webview) return window.chrome.webview.postMessage(text);
      if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.wx)
        return window.webkit.messageHandlers.wx.postMessage(text);
      window.postMessage(payload, "*");
    }}

    window.addEventListener("message", (event) => {{
      const data = typeof event.data === "string" ? JSON.parse(event.data) : event.data;
      if (data && data.action === "login_config") loginConfig = data;
    }});

    wxPost({{ command: "get_login_cmd" }});

    document.getElementById("submit").addEventListener("click", async () => {{
      const error = document.getElementById("error");
      error.textContent = "";
      try {{
        if (!loginConfig) throw new Error("Configuracao de login ainda nao chegou.");
        const pkce = loginConfig.pkce || {{}};
        const response = await fetch((loginConfig.backend_url || fallbackBaseUrl) + "/auth/chromacolors/login", {{
          method: "POST",
          headers: {{ "Content-Type": "application/json", "apikey": loginConfig.apikey || "" }},
          body: JSON.stringify({{
            name: document.getElementById("name").value,
            email: document.getElementById("email").value,
            password: document.getElementById("password").value,
            state: pkce.state,
            code_challenge: pkce.code_challenge,
            code_challenge_method: pkce.code_challenge_method || "S256"
          }})
        }});
        const data = await response.json();
        if (!response.ok) throw new Error(data.error || "Falha no login.");
        wxPost({{ command: "user_login", data: {{ code: data.code, state: data.state }} }});
      }} catch (err) {{
        error.textContent = err.message || String(err);
      }}
    }});
  </script>
</body>
</html>"""


class Handler(BaseHTTPRequestHandler):
    server_version = "ChromaColorsCloud/0.1"

    def log_message(self, fmt: str, *args: Any) -> None:
        print(f"{self.address_string()} - {fmt % args}")

    def send_cors(self) -> None:
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "authorization,content-type,apikey")
        self.send_header("Access-Control-Allow-Methods", "GET,POST,OPTIONS")

    def json_response(self, data: Any, status: int = 200) -> None:
        body = json_dumps(data)
        self.send_response(status)
        self.send_cors()
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def html_response(self, body: str, status: int = 200) -> None:
        encoded = body.encode("utf-8")
        self.send_response(status)
        self.send_cors()
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(encoded)))
        self.end_headers()
        self.wfile.write(encoded)

    def current_user(self) -> sqlite3.Row | None:
        auth = self.headers.get("Authorization", "")
        if not auth.lower().startswith("bearer "):
            return None
        payload = decode_token(auth.split(" ", 1)[1])
        if not payload:
            return None
        with db() as con:
            return con.execute("select * from users where id = ?", (payload.get("sub"),)).fetchone()

    def do_OPTIONS(self) -> None:
        self.send_response(204)
        self.send_cors()
        self.end_headers()

    def do_GET(self) -> None:
        path = urlparse(self.path).path
        if path in ("/", "/cromacolors-login"):
            self.html_response(login_page())
            return
        if path == "/api/v1/health":
            self.json_response({"status": "ok", "service": APP_NAME, "time": now()})
            return
        if path == "/api/v1/sync/profiles":
            user = self.current_user()
            if not user:
                self.json_response({"error": "unauthorized"}, HTTPStatus.UNAUTHORIZED)
                return
            with db() as con:
                rows = con.execute(
                    "select item_key, payload, updated_at from sync_items where user_id = ? order by updated_at desc",
                    (user["id"],),
                ).fetchall()
            self.json_response({"profiles": [json.loads(row["payload"]) for row in rows]})
            return
        if path == "/api/v1/subscriptions":
            self.json_response({"subscriptions": [], "active": False})
            return
        self.json_response({"error": "not found"}, HTTPStatus.NOT_FOUND)

    def do_POST(self) -> None:
        path = urlparse(self.path).path
        query = parse_qs(urlparse(self.path).query)
        try:
            if path == "/auth/chromacolors/login":
                body = read_json(self)
                email = str(body.get("email", "")).strip().lower()
                password = str(body.get("password", ""))
                state = str(body.get("state", ""))
                challenge = str(body.get("code_challenge", ""))
                method = str(body.get("code_challenge_method", "S256"))
                if "@" not in email or len(password) < 6 or not state or not challenge:
                    self.json_response({"error": "invalid login data"}, HTTPStatus.BAD_REQUEST)
                    return
                user = get_or_create_user(email, password, str(body.get("name", "")))
                code = create_auth_code(user["id"], state, challenge, method)
                self.json_response({"code": code, "state": state})
                return

            if path == "/auth/v1/token":
                grant_type = query.get("grant_type", [""])[0]
                body = read_json(self)
                if grant_type == "pkce":
                    self.exchange_pkce(body)
                    return
                if grant_type == "refresh_token":
                    self.refresh_token(body)
                    return
                self.json_response({"error": "unsupported grant_type"}, HTTPStatus.BAD_REQUEST)
                return

            if path == "/auth/v1/logout":
                body = read_json(self)
                token = str(body.get("refresh_token", ""))
                auth = self.headers.get("Authorization", "")
                with db() as con:
                    if token:
                        con.execute(
                            "update refresh_tokens set revoked_at = ? where token_hash = ?",
                            (now(), hash_token(token)),
                        )
                    elif auth.lower().startswith("bearer "):
                        payload = decode_token(auth.split(" ", 1)[1])
                        if payload:
                            con.execute(
                                "update refresh_tokens set revoked_at = ? where user_id = ?",
                                (now(), payload.get("sub")),
                            )
                self.json_response({"success": True})
                return

            if path == "/api/v1/sync/pull":
                self.sync_pull()
                return
            if path == "/api/v1/sync/push":
                self.sync_push()
                return
            if path == "/api/v1/sync/delete":
                self.sync_delete()
                return

            self.json_response({"error": "not found"}, HTTPStatus.NOT_FOUND)
        except ValueError as exc:
            self.json_response({"error": str(exc)}, HTTPStatus.UNAUTHORIZED)
        except json.JSONDecodeError:
            self.json_response({"error": "invalid json"}, HTTPStatus.BAD_REQUEST)
        except Exception as exc:
            self.json_response({"error": "server error", "detail": str(exc)}, HTTPStatus.INTERNAL_SERVER_ERROR)

    def exchange_pkce(self, body: dict[str, Any]) -> None:
        code = str(body.get("auth_code", ""))
        verifier = str(body.get("code_verifier", ""))
        with db() as con:
            auth_code = con.execute("select * from auth_codes where code = ?", (code,)).fetchone()
            if not auth_code or auth_code["used_at"] or auth_code["expires_at"] < now():
                self.json_response({"error": "invalid auth code"}, HTTPStatus.UNAUTHORIZED)
                return
            if auth_code["code_challenge_method"] == "S256" and sha256_pkce(verifier) != auth_code["code_challenge"]:
                self.json_response({"error": "invalid code verifier"}, HTTPStatus.UNAUTHORIZED)
                return
            user = con.execute("select * from users where id = ?", (auth_code["user_id"],)).fetchone()
            con.execute("update auth_codes set used_at = ? where code = ?", (now(), code))
        self.json_response(session_payload(user))

    def refresh_token(self, body: dict[str, Any]) -> None:
        refresh = str(body.get("refresh_token", ""))
        with db() as con:
            token_row = con.execute(
                "select * from refresh_tokens where token_hash = ? and revoked_at is null",
                (hash_token(refresh),),
            ).fetchone()
            if not token_row:
                self.json_response({"error": "invalid refresh token"}, HTTPStatus.UNAUTHORIZED)
                return
            user = con.execute("select * from users where id = ?", (token_row["user_id"],)).fetchone()
        self.json_response(session_payload(user, refresh))

    def sync_pull(self) -> None:
        user = self.current_user()
        if not user:
            self.json_response({"error": "unauthorized"}, HTTPStatus.UNAUTHORIZED)
            return
        with db() as con:
            rows = con.execute(
                "select item_key, payload, updated_at from sync_items where user_id = ? order by updated_at asc",
                (user["id"],),
            ).fetchall()
        items = [json.loads(row["payload"]) for row in rows]
        self.json_response({"upserts": items, "deletes": [], "next_cursor": now(), "server_time": now()})

    def sync_push(self) -> None:
        user = self.current_user()
        if not user:
            self.json_response({"error": "unauthorized"}, HTTPStatus.UNAUTHORIZED)
            return
        body = read_json(self)
        items = body.get("items") or body.get("upserts") or body.get("profiles") or []
        if isinstance(items, dict):
            items = [items]
        saved = 0
        with db() as con:
            for item in items:
                if not isinstance(item, dict):
                    continue
                item_key = str(item.get("id") or item.get("key") or item.get("name") or secrets.token_hex(12))
                con.execute(
                    """
                    insert into sync_items (user_id, item_key, payload, updated_at)
                    values (?, ?, ?, ?)
                    on conflict(user_id, item_key) do update set payload = excluded.payload, updated_at = excluded.updated_at
                    """,
                    (user["id"], item_key, json.dumps(item, ensure_ascii=True), now()),
                )
                saved += 1
        self.json_response({"success": True, "saved": saved, "server_time": now()})

    def sync_delete(self) -> None:
        user = self.current_user()
        if not user:
            self.json_response({"error": "unauthorized"}, HTTPStatus.UNAUTHORIZED)
            return
        body = read_json(self)
        keys = body.get("keys") or body.get("ids") or []
        if isinstance(keys, str):
            keys = [keys]
        deleted = 0
        with db() as con:
            for key in keys:
                result = con.execute(
                    "delete from sync_items where user_id = ? and item_key = ?",
                    (user["id"], str(key)),
                )
                deleted += result.rowcount
        self.json_response({"success": True, "deleted": deleted, "server_time": now()})


def main() -> None:
    init_db()
    host = os.environ.get("CHROMA_HOST", "0.0.0.0")
    port = int(os.environ.get("CHROMA_PORT", "8080"))
    httpd = ThreadingHTTPServer((host, port), Handler)
    print(f"{APP_NAME} listening on http://{host}:{port}")
    print(f"Public URL: {BASE_URL}")
    httpd.serve_forever()


if __name__ == "__main__":
    main()
