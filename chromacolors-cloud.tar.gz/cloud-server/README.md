# ChromaColors Cloud Server

Servidor inicial para o Cloud da ChromaColors. Ele usa apenas a biblioteca
padrao do Python, entao pode rodar em uma VPS limpa sem instalar dependencias.

## Rodar localmente

```bash
cd cloud-server
CHROMA_SECRET="troque-por-uma-chave-grande" python3 server.py
```

Abra:

```text
http://localhost:8080/api/v1/health
```

## Variaveis de ambiente

```text
CHROMA_HOST=0.0.0.0
CHROMA_PORT=8080
CHROMA_BASE_URL=https://claud.chromacolor.shop
CHROMA_PUBLIC_KEY=cromacolors_publishable_key
CHROMA_SECRET=troque-por-uma-chave-grande
CHROMA_DATA_DIR=./data
```

## Endpoints

```text
GET  /cromacolors-login
GET  /api/v1/health
POST /auth/chromacolors/login
POST /auth/v1/token?grant_type=pkce
POST /auth/v1/token?grant_type=refresh_token
POST /auth/v1/logout
POST /api/v1/sync/pull
POST /api/v1/sync/push
POST /api/v1/sync/delete
GET  /api/v1/sync/profiles
GET  /api/v1/subscriptions
```

## Publicar no dominio

No servidor, rode este app em uma porta interna, por exemplo `8080`, e coloque
um proxy HTTPS apontando `https://claud.chromacolor.shop` para essa porta.

Para Ubuntu 25.04, use o pacote pronto em:

```text
deploy/README-ubuntu.md
deploy/install_ubuntu.sh
```

Exemplo de Nginx:

```nginx
server {
    server_name claud.chromacolor.shop;

    location / {
        proxy_pass http://127.0.0.1:8080;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

Depois ative TLS com Certbot ou com o painel do seu provedor.

## Observacao

Este e um MVP funcional: login, criacao de conta, token PKCE, refresh token e
endpoints de sync basicos. Para producao, o proximo passo e reforcar seguranca,
backup do SQLite ou migracao para PostgreSQL, painel administrativo e regras de
sincronizacao completas.
