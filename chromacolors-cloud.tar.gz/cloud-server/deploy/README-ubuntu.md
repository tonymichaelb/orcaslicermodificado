# Ubuntu 25.04 Deploy

Este pacote instala o servidor ChromaColors Cloud no Ubuntu 25.04 usando:

- Python 3
- SQLite em `/var/lib/chromacolors-cloud`
- `systemd`
- Nginx como proxy reverso

## 1. Enviar arquivos para o servidor

Importante: os comandos `tar` e `scp` desta primeira etapa sao executados no
Mac, nao dentro do Ubuntu. O arquivo precisa sair do seu computador e ir para o
servidor.

No seu computador, dentro da pasta do projeto, crie um pacote:

```bash
tar -czf chromacolors-cloud.tar.gz cloud-server
```

Envie o pacote para o servidor:

```bash
scp chromacolors-cloud.tar.gz usuario@SEU_IP:/tmp/
```

Entre no servidor:

```bash
ssh usuario@SEU_IP
```

## 2. Instalar

```bash
cd /tmp
tar -xzf chromacolors-cloud.tar.gz
cd cloud-server
sudo DOMAIN=claud.chromacolor.shop bash deploy/install_ubuntu.sh
```

## 3. Testar no servidor

```bash
curl http://127.0.0.1:8080/api/v1/health
```

Se responder `status: ok`, o app esta rodando.

## 4. Ativar HTTPS

O dominio `claud.chromacolor.shop` precisa apontar no DNS para o IP do servidor.
Depois rode:

Se aparecer `NXDOMAIN`, o DNS ainda nao foi criado. Crie um registro `A`:

```text
Nome: claud
Valor: IP publico do servidor Ubuntu
```

```bash
sudo apt-get install -y certbot python3-certbot-nginx
sudo certbot --nginx -d claud.chromacolor.shop --email seu-email@exemplo.com --agree-tos
```

Se voce nao quiser informar email, use:

```bash
sudo certbot --nginx -d claud.chromacolor.shop --register-unsafely-without-email --agree-tos
```

Teste publicamente:

```bash
curl https://claud.chromacolor.shop/api/v1/health
```

## 5. Comandos uteis

```bash
sudo systemctl status chromacolors-cloud
sudo journalctl -u chromacolors-cloud -f
sudo systemctl restart chromacolors-cloud
sudo nginx -t
sudo systemctl reload nginx
```

## 6. Onde ficam os arquivos

```text
/opt/chromacolors-cloud/server.py
/etc/chromacolors-cloud/cloud.env
/var/lib/chromacolors-cloud/chromacolors_cloud.sqlite3
/etc/systemd/system/chromacolors-cloud.service
/etc/nginx/sites-available/chromacolors-cloud
```

## 7. Atualizar o servidor depois

Copie o novo `server.py` e reinicie:

```bash
sudo cp cloud-server/server.py /opt/chromacolors-cloud/server.py
sudo systemctl restart chromacolors-cloud
```
