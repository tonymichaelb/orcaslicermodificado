#!/usr/bin/env bash
set -euo pipefail

DOMAIN="${DOMAIN:-claud.chromacolor.shop}"
APP_USER="chromacolors-cloud"
APP_DIR="/opt/chromacolors-cloud"
DATA_DIR="/var/lib/chromacolors-cloud"
CONFIG_DIR="/etc/chromacolors-cloud"
SERVICE_FILE="/etc/systemd/system/chromacolors-cloud.service"
NGINX_FILE="/etc/nginx/sites-available/chromacolors-cloud"

if [[ "${EUID}" -ne 0 ]]; then
    echo "Run as root: sudo bash deploy/install_ubuntu.sh"
    exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SOURCE_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"

echo "Installing system packages..."
apt-get update
apt-get install -y python3 nginx openssl ca-certificates curl

if ! id "${APP_USER}" >/dev/null 2>&1; then
    useradd --system --home "${APP_DIR}" --shell /usr/sbin/nologin "${APP_USER}"
fi

install -d -m 0755 "${APP_DIR}"
install -d -m 0750 -o "${APP_USER}" -g "${APP_USER}" "${DATA_DIR}"
install -d -m 0750 "${CONFIG_DIR}"
install -m 0644 "${SOURCE_DIR}/server.py" "${APP_DIR}/server.py"
chown -R root:root "${APP_DIR}"

SECRET="$(openssl rand -hex 32)"
cat > "${CONFIG_DIR}/cloud.env" <<EOF
CHROMA_HOST=127.0.0.1
CHROMA_PORT=8080
CHROMA_BASE_URL=https://${DOMAIN}
CHROMA_PUBLIC_KEY=cromacolors_publishable_key
CHROMA_SECRET=${SECRET}
CHROMA_DATA_DIR=${DATA_DIR}
EOF
chmod 0640 "${CONFIG_DIR}/cloud.env"
chown root:"${APP_USER}" "${CONFIG_DIR}/cloud.env"

install -m 0644 "${SCRIPT_DIR}/chromacolors-cloud.service" "${SERVICE_FILE}"

sed "s/server_name .*/server_name ${DOMAIN};/" "${SCRIPT_DIR}/nginx.chromacolors-cloud.conf" > "${NGINX_FILE}"
ln -sfn "${NGINX_FILE}" /etc/nginx/sites-enabled/chromacolors-cloud
rm -f /etc/nginx/sites-enabled/default

systemctl daemon-reload
systemctl enable --now chromacolors-cloud
nginx -t
systemctl reload nginx

echo
echo "ChromaColors Cloud installed."
echo "Health check:"
echo "  curl http://127.0.0.1:8080/api/v1/health"
echo
echo "To enable HTTPS, run:"
echo "  apt-get install -y certbot python3-certbot-nginx"
echo "  certbot --nginx -d ${DOMAIN}"
