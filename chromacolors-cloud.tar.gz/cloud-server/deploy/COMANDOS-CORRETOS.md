# Comandos corretos para instalar no Ubuntu

O erro do log aconteceu porque o comando `scp` foi executado dentro do Ubuntu.
Esse comando precisa ser executado no Mac, onde o arquivo
`chromacolors-cloud.tar.gz` existe.

## 1. No Mac

Abra um terminal no Mac dentro da pasta:

```text
/Users/tonymichaelbatistadelima/Downloads/OrcaSlicer-main
```

Confira que o pacote existe:

```bash
ls -lh chromacolors-cloud.tar.gz
```

Envie para o servidor. Troque `IP_DO_SERVIDOR` pelo IP real do Ubuntu:

```bash
scp chromacolors-cloud.tar.gz root@IP_DO_SERVIDOR:/tmp/
```

Exemplo:

```bash
scp chromacolors-cloud.tar.gz root@123.123.123.123:/tmp/
```

## 2. No Ubuntu

Depois de enviar pelo Mac, entre no servidor e rode:

```bash
cd /tmp
ls -lh chromacolors-cloud.tar.gz
tar -xzf chromacolors-cloud.tar.gz
cd cloud-server
sudo DOMAIN=claud.chromacolor.shop bash deploy/install_ubuntu.sh
```

Teste:

```bash
curl http://127.0.0.1:8080/api/v1/health
```

## 3. DNS antes do HTTPS

O erro `NXDOMAIN` significa que o dominio ainda nao existe no DNS.

Antes de rodar o Certbot, crie no painel do seu dominio:

```text
Tipo: A
Nome: claud
Valor: IP_DO_SERVIDOR
TTL: automatico
```

Se o nome correto for `cloud.chromacolor.shop`, crie:

```text
Tipo: A
Nome: cloud
Valor: IP_DO_SERVIDOR
TTL: automatico
```

Nesse caso tambem instale usando:

```bash
sudo DOMAIN=cloud.chromacolor.shop bash deploy/install_ubuntu.sh
```

## 4. HTTPS depois do DNS

Somente depois que o DNS apontar para o servidor:

```bash
sudo certbot --nginx -d claud.chromacolor.shop --email seu-email@exemplo.com --agree-tos
```

Ou sem email:

```bash
sudo certbot --nginx -d claud.chromacolor.shop --register-unsafely-without-email --agree-tos
```
